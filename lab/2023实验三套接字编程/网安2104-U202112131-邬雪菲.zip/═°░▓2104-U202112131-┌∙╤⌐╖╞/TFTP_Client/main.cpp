/*��Ҫ����ģ��*/
#include "tftp.h"
using namespace std;
int main()
{
    SOCKET sock = getUdpSocket();
    int recvTimeout = 1000; // 1000ms
    int sendTimeout = 1000;
    // Ϊsocket���ö�ȡ��ʱʱ��
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&recvTimeout, sizeof(int));
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&sendTimeout, sizeof(int));
    // ѡ�������IP
    printf("\n----------------------------------------------------------\n");
    printf("Please choose the TFTP server IP.\n");
    printf("Enter the corresponding number and press Enter.\n");
    printf("    0.Default IP (%s)\n", DEFAULT_IP);
    printf("    1.Other IP (manual input required)\n");
    printf("----------------------------------------------------------\n\n");
    int option;
    scanf("%d", &option);
    char serverip[20];
    if (option == 0)
        strcpy(serverip, DEFAULT_IP);
    else
    {
        printf("Please input the server IP:\n");
        scanf("%s", serverip);
    }
    // ���÷�����IP�Ͷ˿ڶ�Ӧ�ĵ�ַ��
    sockaddr_in addr = getAddr(serverip, SPORT);
    // �����û�������ִ��
    while (1)
    {
        printf("\n----------------------------------------------------------\n");
        printf("Please choose the operation you want to perform.\n");
        printf("Enter the corresponding number and press Enter.\n");
        printf("    0.Close the client terminal\n");
        printf("    1.Upload file\n");
        printf("    2.Download file\n");
        printf("----------------------------------------------------------\n\n");
        int option;
        scanf("%d", &option);
        if (option == 1)
            Upload(sock, addr);
        else if (option == 2)
            Download(sock, addr);
        else
            break;
    }
    return 0;
}